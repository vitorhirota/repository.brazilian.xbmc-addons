BR Play
======================

![screenshot-01.jpg](https://github.com/olavopeixoto/plugin.video.brplay/raw/develop/resources/screenshots/screenshot-01.jpg)

![screenshot-02.jpg](https://github.com/olavopeixoto/plugin.video.brplay/raw/develop/resources/screenshots/screenshot-02.jpg)

![screenshot-03.jpg](https://github.com/olavopeixoto/plugin.video.brplay/raw/develop/resources/screenshots/screenshot-03.jpg)

![screenshot-04.jpg](https://github.com/olavopeixoto/plugin.video.brplay/raw/develop/resources/screenshots/screenshot-04.jpg)

![screenshot-05.jpg](https://github.com/olavopeixoto/plugin.video.brplay/raw/develop/resources/screenshots/screenshot-05.jpg)

![screenshot-06.jpg](https://github.com/olavopeixoto/plugin.video.brplay/raw/develop/resources/screenshots/screenshot-06.jpg)

![screenshot-07.jpg](hhttps://github.com/olavopeixoto/plugin.video.brplay/raw/develop/resources/screenshots/screenshot-07.jpg)

![screenshot-08.jpg](https://github.com/olavopeixoto/plugin.video.brplay/raw/develop/resources/screenshots/screenshot-08.jpg)

License
-------
This software is released under the [GPL 3.0 license] [1].
[1]: http://www.gnu.org/licenses/gpl-3.0.html
