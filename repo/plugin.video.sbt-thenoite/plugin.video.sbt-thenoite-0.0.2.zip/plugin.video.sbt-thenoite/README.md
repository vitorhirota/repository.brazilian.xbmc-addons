# Sobre

Este é um Video Add-on para o XBMC aonde você pode assistir os programas na íntegra do The Noite.

O plugin busca os vídeos direto no site do SBT, assim você não tem os cortes que acontecem nos vídeos 
do canal no Youtube do programa.