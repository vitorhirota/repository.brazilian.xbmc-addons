# Sobre

Este é um Video Add-on para o XBMC aonde você pode assistir os programas na íntegra do The Noite.

O plugin busca os vídeos direto no site do SBT, assim você não tem os cortes que acontecem nos vídeos 
do canal do The Noite no Youtube.

# Instalação

Após instalar o repositório brasileiro, no XBMC, acesse Sistema > Add-ons > Obter Add-ons, selecione
o repositório recém instalado. Vá em Add-ons de vídeo e selecione o plugin SBT The Noite - Programas 
na Integra.

# Utilização

Para usar o plugin, acesse Videos > Add-ons > SBT The Noite - Programas na Integra

Você verá a lista dos programas Na Íntegra. Você pode dar o play em cada parte do programa separadamente, 
ou então entre no menu de contexto (tecla c, normalmente) e selecione 'Tocar episódio inteiro'.