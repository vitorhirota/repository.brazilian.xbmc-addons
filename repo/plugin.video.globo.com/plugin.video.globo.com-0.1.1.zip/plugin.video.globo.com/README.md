# Globo.com XBMC Plugin

Plugin para ver os vídeos específicos para assinantes dos serviços Globo.tv+ e GlobosatPlay.

Globo.tv+ é um serviço disponível para assinatura online.

GlobosatPlay é um serviço exclusivo para assinantes CTBC, GVT, NET, NET Angra, Multiplay, TV Oi, Sky e Vivo.

Por enquanto, apenas autenticação para GVT está disponível.

---

Watch subscriber movies from Globo.tv+ and GlobosatPlay.

Globo.tv+ is avaiable for anyone.

GlobosatPlay is exclusive for CTBC, GVT, NET, NET Angra, Multiplay, TV Oi, Sky and Vivo subscribers.
