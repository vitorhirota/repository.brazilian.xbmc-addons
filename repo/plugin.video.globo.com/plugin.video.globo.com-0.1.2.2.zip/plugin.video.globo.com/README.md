# Globo.com XBMC Plugin

Plugin para ver os vídeos específicos para assinantes dos serviços Globo.tv+ e GlobosatPlay.

Globo.tv+ é um serviço disponível para quem for assinante globo.com.

GlobosatPlay é um serviço para assinantes CTBC, GVT, NET, NET Angra, Multiplay, TV Oi, Sky e Vivo.

Por enquanto, apenas autenticação para GVT está disponível.

---

Watch subscriber videos from Globo.tv+ and GlobosatPlay.

Globo.tv+ is avaiable for globo.com subscribers.

GlobosatPlay is available for CTBC, GVT, NET, NET Angra, Multiplay, TV Oi, Sky and Vivo subscribers.
