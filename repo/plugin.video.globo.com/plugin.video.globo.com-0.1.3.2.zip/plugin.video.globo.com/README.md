# Globo.com XBMC Plugin

Plugin para ver os vídeos específicos para assinantes dos serviços Globo.tv+ e GlobosatPlay.

Globo.tv+ é um serviço disponível para quem for assinante globo.com.

GlobosatPlay é um serviço para assinantes CTBC, GVT, NET, NET Angra, Multiplay, TV Oi, Sky e Vivo.

Por enquanto, apenas autenticação para GVT e NET está disponível.

Se quiser me doar uma cerveja, use o link abaixo :)
<a href=https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=C4DH8F642RYEG&lc=US&item_name=Vitor%20Hirota&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted"><img src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif"></a>


---

Watch subscriber videos from Globo.tv+ and GlobosatPlay.

Globo.tv+ is avaiable for globo.com subscribers.

GlobosatPlay is available for CTBC, GVT, NET, NET Angra, Multiplay, TV Oi, Sky and Vivo subscribers.

If you would like to donate me a beer, use the link below :)
<a href=https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=C4DH8F642RYEG&lc=US&item_name=Vitor%20Hirota&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted"><img src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif"></a>
