# Globo.tv XBMC Plugin

Veja os vídeos disponibilizados gratuitamente pelo site http://globotv.globo.com

Inclui vídeos dos canais Globo, GNT, Multishow, Sportv, Globo News, Canal Brasil, entre outros.

Para alterações, verifique o [changelog](https://github.com/vitorhirota/plugin.video.globotv/blob/master/changelog.txt).

Para downloads de arquivos .zip de instalação, veja a página de [tags](https://github.com/vitorhirota/plugin.video.globotv/tags).

--- 

Watch Globo TV videos freely available online.

Check the [tags](https://github.com/vitorhirota/plugin.video.globotv/tags) page for pre-packaged .zip install files.

[![githalytics.com alpha](https://cruel-carlota.pagodabox.com/8f485bc414511ca598e31767d5746cdf "githalytics.com")](http://githalytics.com/vitorhirota/plugin.video.globotv)
